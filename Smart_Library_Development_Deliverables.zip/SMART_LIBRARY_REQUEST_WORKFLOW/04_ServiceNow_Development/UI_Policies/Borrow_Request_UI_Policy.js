/*
 * UI Policy: Make Return Date Mandatory When Issued
 * Table: u_borrow_request
 * Condition: Status is Issued
 * Applies to: Platform UI + Service Portal
 *
 * Configure in UI Policy record:
 *   - Table: u_borrow_request
 *   - Conditions: status = issued
 *   - Reverse if false: true
 *   - Script type: Advanced (both boxes below go in "Script - if true" / "Script - if false")
 */

// ===== Script - if true (Status = Issued) =====
function onCondition() {
    g_form.setMandatory('return_date', true);
    g_form.setVisible('return_date', true);

    // Once issued, prevent changing the borrower or the book on this request
    g_form.setReadOnly('book', true);
    g_form.setReadOnly('requested_by', true);
}

// ===== Script - if false (Status != Issued) =====
function onConditionFalse() {
    g_form.setMandatory('return_date', false);

    // Return Date is not relevant before a book is actually issued
    if (g_form.getValue('status') === 'requested') {
        g_form.setVisible('return_date', false);
    }

    g_form.setReadOnly('book', false);
    g_form.setReadOnly('requested_by', false);
}

/*
 * Companion UI Policy: Lock Request After Approval
 * Table: u_borrow_request
 * Condition: Status is Approved OR Status is Issued OR Status is Returned
 */
function onCondition_LockAfterApproval() {
    g_form.setReadOnly('book', true);
    g_form.setReadOnly('requested_by', true);
    g_form.setReadOnly('request_date', true);
}

function onConditionFalse_LockAfterApproval() {
    g_form.setReadOnly('book', false);
    g_form.setReadOnly('requested_by', false);
    g_form.setReadOnly('request_date', false);
}
