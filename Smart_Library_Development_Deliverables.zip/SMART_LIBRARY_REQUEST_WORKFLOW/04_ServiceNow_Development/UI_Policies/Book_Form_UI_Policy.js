/*
 * UI Policy: Lock Core Fields While Book Is Issued
 * Table: u_book
 * Condition: Status is Issued
 * Purpose: Prevent librarians from editing catalog details (Title/Author/ISBN)
 *          while a book is actively on loan, avoiding data drift against the
 *          open Borrow Request record.
 */

// ===== Script - if true (Status = Issued) =====
function onCondition() {
    g_form.setReadOnly('title', true);
    g_form.setReadOnly('author', true);
    g_form.setReadOnly('isbn', true);

    g_form.addInfoMessage('This book is currently issued. Catalog details are locked until it is returned.');
}

// ===== Script - if false (Status != Issued) =====
function onConditionFalse() {
    g_form.setReadOnly('title', false);
    g_form.setReadOnly('author', false);
    g_form.setReadOnly('isbn', false);
}

/*
 * Companion UI Policy: Warn on Lost Status
 * Table: u_book
 * Condition: Status is Lost
 */
function onCondition_LostWarning() {
    g_form.addErrorMessage('This book is marked Lost and will not appear as a selectable option for new borrow requests.');
    g_form.setReadOnly('title', true);
    g_form.setReadOnly('author', true);
    g_form.setReadOnly('isbn', true);
}

function onConditionFalse_LostWarning() {
    // No action required when status is not Lost; handled by the primary policy above
}
