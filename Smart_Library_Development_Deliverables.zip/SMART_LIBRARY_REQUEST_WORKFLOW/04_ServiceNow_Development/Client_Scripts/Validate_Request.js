/*
 * Client Script: Validate Request
 * Table: u_borrow_request
 * Type: onSubmit
 * Purpose: Final client-side safety check to stop a student from submitting
 *          a borrow request for a book that is no longer Available -- covers
 *          the race condition where the book's status changed after the form
 *          was opened but before the reference qualifier re-filtered it.
 */
function onSubmit() {
    var bookSysId = g_form.getValue('book');

    if (!bookSysId) {
        g_form.addErrorMessage('Please select a book before submitting your request.');
        return false;
    }

    var ga = new GlideAjax('BorrowRequestValidator'); // Script Include, server-side
    ga.addParam('sysparm_name', 'isBookAvailable');
    ga.addParam('sysparm_book_id', bookSysId);
    ga.setJSONResponse(true);

    var isValid = true;

    ga.getXMLWait(); // synchronous call required for onSubmit validation
    var response = ga.getAnswer();

    if (response === 'false') {
        g_form.addErrorMessage('This book is no longer available. Please choose a different title.');
        isValid = false;
    }

    return isValid;
}

/*
 * Companion Script Include (server-side, referenced above):
 *
 * var BorrowRequestValidator = Class.create();
 * BorrowRequestValidator.prototype = Object.extendsObject(AbstractAjaxProcessor, {
 *     isBookAvailable: function () {
 *         var bookId = this.getParameter('sysparm_book_id');
 *         var book = new GlideRecord('u_book');
 *         if (book.get(bookId)) {
 *             return (book.getValue('status') === 'available').toString();
 *         }
 *         return 'false';
 *     },
 *     type: 'BorrowRequestValidator'
 * });
 */
