/*
 * Client Script: Auto Populate
 * Table: u_borrow_request
 * Type: onChange
 * Field watched: book
 * Purpose: When a student selects a book, automatically stamp the Request
 *          Date and pre-fill the Requested By field with the current user
 *          on a new (unsaved) record.
 */
function onChange(control, oldValue, newValue, isLoading, isTemplate) {
    if (isLoading || newValue === '') {
        return;
    }

    // Stamp Request Date with "now" the moment a book is chosen
    if (!g_form.getValue('request_date')) {
        var gdt = new GlideDateTime();
        g_form.setValue('request_date', gdt.getDisplayValue());
    }

    // Pre-fill Requested By on new records only, so librarians can still
    // submit on behalf of a student without it being overwritten
    if (g_form.isNewRecord() && !g_form.getValue('requested_by')) {
        g_form.setValue('requested_by', g_user.userID, g_user.getFullName());
    }
}

/*
 * Companion onLoad script for the same table:
 * Defaults Status to "Requested" for any brand-new record opened via the
 * Service Portal "New Request" button, so students never see a blank choice.
 */
function onLoad() {
    if (g_form.isNewRecord() && !g_form.getValue('status')) {
        g_form.setValue('status', 'requested');
    }
}
